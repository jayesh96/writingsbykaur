Warning! 

SASS files are optional! They are not required to start working with MDB.

You don't need to include them in your project.

SASS are inteded for developers who are willing to modify MDB CSS code via SASS files. 
All other users should include either mdb.css or mdb.min.css and skip SASS files.